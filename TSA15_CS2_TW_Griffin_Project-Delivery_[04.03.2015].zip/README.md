## Telerik Software Academy 2015, C# part 2 Teamwork, team "Griffin"
This is the main gate for the teamwork project assignment.
- For information about project's team-members, see [team members](./Team%20Members.md) file;
- For information about project's task assignment, see [project requirements](./Project%20Requirements.md) file;
- For information about project's initial ideas, see [ideas](./Main%20Ideas%20(check%20pending).docx) file;
- For information about project's realisation planning, see [planning](./Planning.md) file;
- For project's documentation, see [documentation](./Documentation.docx) file;
- There is additional source images, used for pseudo-graphics, see [original](./Griffin%5Boriginal%5D.gif) and [paletted](./Griffin%5Bpaletted%5D.png) source image files.
