This list enumerates the team members, sorted in ascending alphabetical order along with their pseudonims in the [Telerik Academy Students system](https://telerikacademy.com/):

1. Angella Teneva - [ellapt](https://telerikacademy.com/Users/ellapt)
2. Vasil Vâlkov - [BaSk3T](https://telerikacademy.com/Users/BaSk3T)
3. Danail Batev - [Didobat](https://telerikacademy.com/Users/Didobat)
4. Kamen Todorov - [kamen_t](https://telerikacademy.com/Users/kamen_t)
5. Martina Mitreva - [martina.mitreva](https://telerikacademy.com/Users/martina.mitreva)
6. Niko Stoyanov - [Zenix](https://telerikacademy.com/Users/Zenix)
7. Nikolay Nikolov - [nikolay.nikolov](https://telerikacademy.com/Users/nikolay.nikolov)
8. Petâr Stamenov - [pitslz](https://telerikacademy.com/Users/pitslz)
